import { Lead, AgentInteraction } from '../types'

// Use environment variables for API configuration
const API_KEY = import.meta.env.VITE_GOOGLE_API_KEY || '';
const SPREADSHEET_ID = '14ZBC57ulhmHqIAbJZvIl2sTJ7CwGB-G2gNgrdEuYaY0';

async function getSheetData(range: string) {
  try {
    const response = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?key=${API_KEY}`
    );
    const data = await response.json();
    return data.values;
  } catch (error) {
    console.error('Error fetching sheet data:', error);
    throw error;
  }
}

export async function importLeadsFromSheet(): Promise<Lead[]> {
  try {
    // Get data from the "Lead" sheet, starting from row 2 (after headers)
    const data = await getSheetData('Lead!A2:AZ')
    
    return data?.map((row) => {
      // Process agent interactions (now supporting more details)
      const agents: AgentInteraction[] = []
      for (let i = 0; i < 10; i++) {
        const baseIndex = 14 + (i * 6) // Start after first 14 columns, now 6 columns per agent
        const agentName = row[baseIndex]
        
        if (agentName) {
          agents.push({
            agentName,
            stage: row[baseIndex + 1] || '',
            comments: row[baseIndex + 2] || '',
            date: row[baseIndex + 3] || '',
            outcome: row[baseIndex + 4] || '',
            nextSteps: row[baseIndex + 5] || ''
          })
        }
      }

      // Parse competitors and tags from comma-separated strings
      const competitors = row[74]?.split(',').map(s => s.trim()).filter(Boolean) || []
      const tags = row[75]?.split(',').map(s => s.trim()).filter(Boolean) || []

      // Create the lead object with new structure
      const lead: Lead = {
        id: row[0] || crypto.randomUUID(),
        month: row[1] || '',
        dateTime: row[2] || new Date().toISOString(),
        name: row[3] || '',
        company: row[4] || '',
        phone: row[5] || '',
        email: row[6] || '',
        state: row[7] || '',
        jobTitle: row[8] || '',
        source: row[9] || '',
        investment: parseFloat(row[10]) || 0,
        service: row[11] || '',
        status: (row[12] || 'new') as Lead['status'],
        notes: row[13] || '',
        
        // New fields
        website: row[70] || '',
        industry: row[71] || '',
        employeeCount: parseInt(row[72]) || undefined,
        annualRevenue: parseFloat(row[73]) || undefined,
        decisionMaker: row[74] || '',
        decisionMakerRole: row[75] || '',
        priority: (row[76] as Lead['priority']) || undefined,
        lastContactDate: row[77] || undefined,
        nextFollowUp: row[78] || undefined,
        linkedInProfile: row[79] || undefined,
        competitors,
        tags,
        
        // Base fields that need to be present
        amount: parseFloat(row[10]) || 0,
        createdAt: row[2] || new Date().toISOString(),
        agents,
        activities: [],
        
        // Custom fields starting from column 80
        customFields: parseCustomFields(row.slice(80))
      }

      // Validate status
      const validStatuses = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'closed']
      if (!validStatuses.includes(lead.status)) {
        lead.status = 'new'
      }

      return lead
    }) || []
  } catch (error) {
    console.error('Error importing leads:', error)
    throw error;
  }
}

function parseCustomFields(customFieldsData: any[]): Record<string, string | number | boolean> {
  const customFields: Record<string, string | number | boolean> = {}
  
  customFieldsData.forEach((value, index) => {
    if (value !== undefined && value !== '') {
      const fieldName = `custom_${index + 1}`
      
      // Try to parse as number
      const numValue = parseFloat(value)
      if (!isNaN(numValue)) {
        customFields[fieldName] = numValue
        return
      }
      
      // Check for boolean
      if (value.toLowerCase() === 'true' || value.toLowerCase() === 'false') {
        customFields[fieldName] = value.toLowerCase() === 'true'
        return
      }
      
      // Default to string
      customFields[fieldName] = value
    }
  })
  
  return customFields
}
