import { Lead, EmailCampaign, CustomField } from '../types'

const LEADS_KEY = 'cracon_leads'
const CAMPAIGNS_KEY = 'cracon_campaigns'
const CUSTOM_FIELDS_KEY = 'cracon_custom_fields'

// Leads
export const getLeads = (): Lead[] => {
  try {
    const leads = localStorage.getItem(LEADS_KEY)
    if (!leads) return []

    const parsedLeads = JSON.parse(leads)
    
    // Ensure all leads have the required properties and maintain new fields
    return parsedLeads.map((lead: any): Lead => ({
      // Required fields
      id: lead.id || crypto.randomUUID(),
      month: lead.month || '',
      dateTime: lead.dateTime || new Date().toISOString(),
      name: lead.name || '',
      company: lead.company || '',
      phone: lead.phone || '',
      email: lead.email || '',
      state: lead.state || '',
      jobTitle: lead.jobTitle || '',
      source: lead.source || '',
      investment: lead.investment || 0,
      service: lead.service || '',
      status: lead.status || 'new',
      notes: lead.notes || '',
      amount: lead.amount || lead.investment || 0,
      createdAt: lead.createdAt || lead.dateTime || new Date().toISOString(),
      agents: Array.isArray(lead.agents) ? lead.agents : [],
      activities: Array.isArray(lead.activities) ? lead.activities : [],
      
      // New optional fields - maintain if they exist
      website: lead.website,
      industry: lead.industry,
      employeeCount: lead.employeeCount,
      annualRevenue: lead.annualRevenue,
      decisionMaker: lead.decisionMaker,
      decisionMakerRole: lead.decisionMakerRole,
      priority: lead.priority,
      lastContactDate: lead.lastContactDate,
      nextFollowUp: lead.nextFollowUp,
      linkedInProfile: lead.linkedInProfile,
      competitors: Array.isArray(lead.competitors) ? lead.competitors : [],
      tags: Array.isArray(lead.tags) ? lead.tags : [],
      customFields: lead.customFields || {}
    }))
  } catch (error) {
    console.error('Error loading leads:', error)
    return []
  }
}

export const saveLead = (lead: Lead) => {
  try {
    const leads = getLeads()
    const existingLeadIndex = leads.findIndex(l => l.id === lead.id)
    
    // Ensure all required fields are present while maintaining optional fields
    const validatedLead: Lead = {
      ...lead,
      // Required fields with defaults
      id: lead.id || crypto.randomUUID(),
      month: lead.month || '',
      dateTime: lead.dateTime || new Date().toISOString(),
      createdAt: lead.createdAt || lead.dateTime || new Date().toISOString(),
      amount: lead.amount || lead.investment || 0,
      agents: Array.isArray(lead.agents) ? lead.agents : [],
      activities: Array.isArray(lead.activities) ? lead.activities : [],
      
      // Optional arrays with defaults if undefined
      competitors: Array.isArray(lead.competitors) ? lead.competitors : [],
      tags: Array.isArray(lead.tags) ? lead.tags : [],
      customFields: lead.customFields || {}
    }
    
    if (existingLeadIndex >= 0) {
      leads[existingLeadIndex] = validatedLead
    } else {
      leads.push(validatedLead)
    }
    
    localStorage.setItem(LEADS_KEY, JSON.stringify(leads))
  } catch (error) {
    console.error('Error saving lead:', error)
    throw new Error('Failed to save lead')
  }
}

export const deleteLead = (id: string) => {
  try {
    const leads = getLeads()
    const filteredLeads = leads.filter(lead => lead.id !== id)
    localStorage.setItem(LEADS_KEY, JSON.stringify(filteredLeads))
  } catch (error) {
    console.error('Error deleting lead:', error)
    throw new Error('Failed to delete lead')
  }
}

// Email Campaigns
export const getCampaigns = (): EmailCampaign[] => {
  const campaigns = localStorage.getItem(CAMPAIGNS_KEY)
  return campaigns ? JSON.parse(campaigns) : []
}

export const saveCampaign = (campaign: EmailCampaign) => {
  const campaigns = getCampaigns()
  const existingIndex = campaigns.findIndex(c => c.id === campaign.id)
  
  if (existingIndex >= 0) {
    campaigns[existingIndex] = campaign
  } else {
    campaigns.push(campaign)
  }
  
  localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns))
}

export const deleteCampaign = (id: string) => {
  const campaigns = getCampaigns()
  const filtered = campaigns.filter(campaign => campaign.id !== id)
  localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(filtered))
}

// Custom Fields
export const getCustomFields = (): CustomField[] => {
  const fields = localStorage.getItem(CUSTOM_FIELDS_KEY)
  return fields ? JSON.parse(fields) : []
}

export const saveCustomField = (field: CustomField) => {
  const fields = getCustomFields()
  const existingIndex = fields.findIndex(f => f.id === field.id)
  
  if (existingIndex >= 0) {
    fields[existingIndex] = field
  } else {
    fields.push(field)
  }
  
  localStorage.setItem(CUSTOM_FIELDS_KEY, JSON.stringify(fields))
}

export const deleteCustomField = (id: string) => {
  const fields = getCustomFields()
  const filtered = fields.filter(field => field.id !== id)
  localStorage.setItem(CUSTOM_FIELDS_KEY, JSON.stringify(filtered))
}
