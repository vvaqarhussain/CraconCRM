import { useEffect, useState } from 'react'
import { ArrowUp, Users, CheckCircle, DollarSign, Clock, Building } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import type { ChartData, ChartOptions } from 'chart.js'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js'
import { DashboardStats, Lead } from '../types'
import { getLeads } from '../utils/storage'

// Register ChartJS components once
if (!ChartJS.overrides.line) {
  ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    ArcElement
  )
}

const StatCard = ({ title, value, icon: Icon, trend }: {
  title: string
  value: number
  icon: typeof Users
  trend?: string
}) => (
  <div className="bg-gradient-to-br from-[#111111] to-[#1a1a1a] p-6 rounded-xl border border-zinc-800 hover:border-orange-500/20 transition-colors">
    <div className="flex justify-between items-start">
      <div>
        <p className="text-white/60 text-sm">{title}</p>
        <p className="text-2xl font-semibold mt-1 text-white">{value}</p>
        {trend && (
          <p className="text-orange-400 text-sm mt-1 flex items-center">
            <ArrowUp className="w-4 h-4 mr-1" />
            {trend} vs last month
          </p>
        )}
      </div>
      <Icon className="w-8 h-8 text-orange-400" />
    </div>
  </div>
)

const RecentLeadCard = ({ lead }: { lead: Lead }) => (
  <div key={lead.id} className="flex items-center gap-4 p-4 bg-[#111111] rounded-lg border border-zinc-800">
    <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center">
      <Building className="w-5 h-5 text-orange-400" />
    </div>
    <div className="flex-1">
      <h3 className="text-sm font-medium text-gray-200">{lead.name}</h3>
      <p className="text-sm text-gray-400">{lead.company}</p>
    </div>
    <div className="text-right">
      <p className="text-sm text-gray-400">
        {new Date(lead.createdAt).toLocaleDateString()}
      </p>
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize bg-orange-500/10 text-orange-400 border border-orange-500/20">
        {lead.status}
      </span>
    </div>
  </div>
)

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalLeads: 0,
    newLeads: 0,
    qualifiedLeads: 0,
    closedLeads: 0,
    totalValue: 0,
    avgDealSize: 0,
    conversionRate: 0
  })
  const [recentLeads, setRecentLeads] = useState<Lead[]>([])
  const [leadsByStatus, setLeadsByStatus] = useState<number[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      const leads = getLeads()
      
      // Update stats
      const totalValue = leads.reduce((sum, lead) => sum + (lead.amount || 0), 0)
      setStats({
        totalLeads: leads.length,
        newLeads: leads.filter(l => l.status === 'new').length,
        qualifiedLeads: leads.filter(l => l.status === 'qualified').length,
        closedLeads: leads.filter(l => l.status === 'closed').length,
        totalValue,
        avgDealSize: leads.length ? totalValue / leads.length : 0,
        conversionRate: leads.length ? (leads.filter(l => l.status === 'closed').length / leads.length) * 100 : 0
      })

      // Get recent leads
      const sortedLeads = [...leads].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      setRecentLeads(sortedLeads.slice(0, 5))

      // Calculate leads by status
      setLeadsByStatus([
        leads.filter(l => l.status === 'new').length,
        leads.filter(l => l.status === 'contacted').length,
        leads.filter(l => l.status === 'qualified').length,
        leads.filter(l => l.status === 'proposal').length,
        leads.filter(l => l.status === 'negotiation').length,
        leads.filter(l => l.status === 'closed').length,
      ])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data')
    }
  }, [])

  const chartData: ChartData<'line'> = {
    labels: ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed'],
    datasets: [
      {
        label: 'Leads by Status',
        data: leadsByStatus,
        fill: true,
        borderColor: '#f97316',
        backgroundColor: 'rgba(249, 115, 22, 0.1)',
        tension: 0.4,
      },
    ],
  }

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#1a1a1a',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#27272a',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
      x: {
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
    },
  }

  if (error) {
    return (
      <div className="text-red-500 p-4">
        Error: {error}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Leads"
          value={stats.totalLeads}
          icon={Users}
          trend="12%"
        />
        <StatCard
          title="New Leads"
          value={stats.newLeads}
          icon={Users}
        />
        <StatCard
          title="Qualified Leads"
          value={stats.qualifiedLeads}
          icon={CheckCircle}
        />
        <StatCard
          title="Closed Deals"
          value={stats.closedLeads}
          icon={DollarSign}
          trend="8%"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart */}
        <div className="bg-[#111111] p-6 rounded-xl border border-zinc-800">
          <h2 className="text-lg font-semibold mb-4 text-white">Lead Distribution</h2>
          <Line data={chartData} options={chartOptions} />
        </div>

        {/* Recent Leads */}
        <div className="bg-[#111111] p-6 rounded-xl border border-zinc-800">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Recent Leads</h2>
            <Clock className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-3">
            {recentLeads.map(lead => (
              <RecentLeadCard key={lead.id} lead={lead} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
