import DashboardCard from '../../components/DashboardCard'

const ExecutiveDashboard = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Executive Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard title="Company Overview">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Revenue YTD</p>
              <p className="text-2xl font-semibold text-white">$4.2M</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Growth Rate</p>
              <p className="text-2xl font-semibold text-white">24%</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Key Metrics">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Customer Satisfaction</p>
              <p className="text-2xl font-semibold text-white">92%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Market Share</p>
              <p className="text-2xl font-semibold text-white">18%</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Strategic Goals">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Initiatives</p>
              <p className="text-2xl font-semibold text-white">8/12</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Completion Rate</p>
              <p className="text-2xl font-semibold text-white">67%</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  )
}

export default ExecutiveDashboard
