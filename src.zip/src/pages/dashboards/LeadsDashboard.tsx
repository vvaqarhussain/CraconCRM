import { useEffect, useState, useRef } from 'react'
import { Plus, ArrowUp, Users, Mail, Phone, Calendar } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import type { ChartData, ChartOptions } from 'chart.js'
import { DashboardStats, Lead } from '../../types'
import { getLeads } from '../../utils/storage'
import DashboardCard from '../../components/DashboardCard'
import '../../utils/chartSetup'

const AVAILABLE_CARDS = {
  leadTrends: 'Lead Trends',
  leadSources: 'Lead Sources',
  leadActivity: 'Lead Activity',
  leadStatus: 'Lead Status',
  recentLeads: 'Recent Leads',
  leadQuality: 'Lead Quality',
  leadEngagement: 'Lead Engagement',
  stats: 'Stats Overview'
} as const

type CardId = keyof typeof AVAILABLE_CARDS

const LeadsDashboard = () => {
  const chartRef = useRef<any>(null)
  const [stats, setStats] = useState<DashboardStats>({
    totalLeads: 0,
    newLeads: 0,
    qualifiedLeads: 0,
    closedLeads: 0,
    totalValue: 0,
    avgDealSize: 0,
    conversionRate: 0
  })
  const [recentLeads, setRecentLeads] = useState<Lead[]>([])
  const [leadsByStatus, setLeadsByStatus] = useState<number[]>([])
  const [activeCards, setActiveCards] = useState<CardId[]>(() => {
    const saved = localStorage.getItem('leads_dashboard_cards')
    return saved ? JSON.parse(saved) : Object.keys(AVAILABLE_CARDS)
  })
  const [showCardSelector, setShowCardSelector] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      const leads = getLeads()
      const totalValue = leads.reduce((sum, lead) => sum + (lead.amount || 0), 0)
      
      setStats({
        totalLeads: leads.length,
        newLeads: leads.filter(l => l.status === 'new').length,
        qualifiedLeads: leads.filter(l => l.status === 'qualified').length,
        closedLeads: leads.filter(l => l.status === 'closed').length,
        totalValue,
        avgDealSize: leads.length ? totalValue / leads.length : 0,
        conversionRate: leads.length ? (leads.filter(l => l.status === 'closed').length / leads.length) * 100 : 0
      })
      
      const sortedLeads = [...leads].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      setRecentLeads(sortedLeads.slice(0, 5))

      setLeadsByStatus([
        leads.filter(l => l.status === 'new').length,
        leads.filter(l => l.status === 'contacted').length,
        leads.filter(l => l.status === 'qualified').length,
        leads.filter(l => l.status === 'proposal').length,
        leads.filter(l => l.status === 'negotiation').length,
        leads.filter(l => l.status === 'closed').length,
      ])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data')
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('leads_dashboard_cards', JSON.stringify(activeCards))
  }, [activeCards])

  useEffect(() => {
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy()
      }
    }
  }, [])

  const toggleCard = (cardId: CardId) => {
    if (activeCards.includes(cardId)) {
      setActiveCards(activeCards.filter(id => id !== cardId))
    } else {
      setActiveCards([...activeCards, cardId])
    }
  }

  const chartData: ChartData<'line'> = {
    labels: ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed'],
    datasets: [
      {
        label: 'Leads by Status',
        data: leadsByStatus,
        fill: true,
        borderColor: '#f97316',
        backgroundColor: 'rgba(249, 115, 22, 0.1)',
        tension: 0.4,
      },
    ],
  }

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#1a1a1a',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#27272a',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
      x: {
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
    },
  }

  if (error) {
    return (
      <div className="text-red-500 p-4">
        Error: {error}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Leads Dashboard</h1>
        <div className="relative">
          <button
            onClick={() => setShowCardSelector(!showCardSelector)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
          >
            <Plus className="w-4 h-4" />
            Manage Cards
          </button>

          {showCardSelector && (
            <div className="absolute right-0 mt-2 w-64 bg-[#1a1a1a] border border-zinc-800 rounded-lg shadow-lg z-10">
              {(Object.entries(AVAILABLE_CARDS) as [CardId, string][]).map(([id, title]) => (
                <label key={id} className="flex items-center px-4 py-2 hover:bg-zinc-800">
                  <input
                    type="checkbox"
                    checked={activeCards.includes(id)}
                    onChange={() => toggleCard(id)}
                    className="mr-3"
                  />
                  <span className="text-sm text-gray-300">{title}</span>
                </label>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {activeCards.includes('stats') && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <DashboardCard title="Total Leads" onRemove={() => toggleCard('stats')}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">{stats.totalLeads}</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <ArrowUp className="w-4 h-4 mr-1" />
                  15% vs last month
                </p>
              </div>
              <Users className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Contacted Today">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">24</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <Phone className="w-4 h-4 mr-1" />
                  12 calls made
                </p>
              </div>
              <Mail className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Follow-ups Due">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">18</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  Today
                </p>
              </div>
              <Calendar className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Lead Quality Score">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">7.8</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <ArrowUp className="w-4 h-4 mr-1" />
                  0.5 vs last week
                </p>
              </div>
              <Users className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeCards.includes('leadTrends') && (
          <DashboardCard
            title="Lead Trends"
            onRemove={() => toggleCard('leadTrends')}
          >
            <div style={{ height: '300px' }}>
              <Line
                ref={chartRef}
                data={chartData}
                options={chartOptions}
              />
            </div>
          </DashboardCard>
        )}

        {activeCards.includes('leadSources') && (
          <DashboardCard
            title="Lead Sources"
            onRemove={() => toggleCard('leadSources')}
          >
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Website</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-3/4 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">75%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Referrals</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-1/2 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">50%</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Social Media</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-1/4 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">25%</span>
                </div>
              </div>
            </div>
          </DashboardCard>
        )}
      </div>

      {activeCards.includes('recentLeads') && (
        <DashboardCard
          title="Recent Leads"
          onRemove={() => toggleCard('recentLeads')}
        >
          <div className="space-y-4">
            {recentLeads.map((lead, index) => (
              <div key={index} className="flex justify-between items-center">
                <div>
                  <p className="text-white font-medium">{lead.name}</p>
                  <p className="text-sm text-gray-400">{lead.email}</p>
                </div>
                <span className="px-3 py-1 text-sm rounded-full bg-orange-500/10 text-orange-500">
                  {lead.status}
                </span>
              </div>
            ))}
          </div>
        </DashboardCard>
      )}

      {activeCards.includes('leadEngagement') && (
        <DashboardCard
          title="Lead Engagement Metrics"
          onRemove={() => toggleCard('leadEngagement')}
        >
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-400">Email Open Rate</p>
              <p className="text-2xl font-semibold text-white">42.8%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Response Time</p>
              <p className="text-2xl font-semibold text-white">2.4h</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Engagement Score</p>
              <p className="text-2xl font-semibold text-white">8.5</p>
            </div>
          </div>
        </DashboardCard>
      )}
    </div>
  )
}

export default LeadsDashboard
