import { useEffect, useState, useRef } from 'react'
import { Plus, ArrowUp, Box, Clock, CheckCircle, AlertTriangle } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import type { ChartData, ChartOptions } from 'chart.js'
import DashboardCard from '../../components/DashboardCard'
import '../../utils/chartSetup'

const AVAILABLE_CARDS = {
  productionOverview: 'Production Overview',
  orderStatus: 'Order Status',
  productionEfficiency: 'Production Efficiency',
  qualityMetrics: 'Quality Metrics',
  workInProgress: 'Work in Progress',
  bottlenecks: 'Production Bottlenecks',
  timeline: 'Production Timeline',
  stats: 'Stats Overview'
} as const

type CardId = keyof typeof AVAILABLE_CARDS

const ProductionDashboard = () => {
  const chartRef = useRef<any>(null)
  const [activeCards, setActiveCards] = useState<CardId[]>(() => {
    const saved = localStorage.getItem('production_dashboard_cards')
    return saved ? JSON.parse(saved) : Object.keys(AVAILABLE_CARDS)
  })
  const [showCardSelector, setShowCardSelector] = useState(false)

  useEffect(() => {
    localStorage.setItem('production_dashboard_cards', JSON.stringify(activeCards))
  }, [activeCards])

  const toggleCard = (cardId: CardId) => {
    if (activeCards.includes(cardId)) {
      setActiveCards(activeCards.filter(id => id !== cardId))
    } else {
      setActiveCards([...activeCards, cardId])
    }
  }

  const productionData: ChartData<'line'> = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Units Produced',
        data: [150, 180, 165, 190, 175, 160, 170],
        fill: true,
        borderColor: '#f97316',
        backgroundColor: 'rgba(249, 115, 22, 0.1)',
        tension: 0.4,
      },
    ],
  }

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#1a1a1a',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#27272a',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
      x: {
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
    },
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Production Dashboard</h1>
        <div className="relative">
          <button
            onClick={() => setShowCardSelector(!showCardSelector)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
          >
            <Plus className="w-4 h-4" />
            Manage Cards
          </button>

          {showCardSelector && (
            <div className="absolute right-0 mt-2 w-64 bg-[#1a1a1a] border border-zinc-800 rounded-lg shadow-lg z-10">
              {(Object.entries(AVAILABLE_CARDS) as [CardId, string][]).map(([id, title]) => (
                <label key={id} className="flex items-center px-4 py-2 hover:bg-zinc-800">
                  <input
                    type="checkbox"
                    checked={activeCards.includes(id)}
                    onChange={() => toggleCard(id)}
                    className="mr-3"
                  />
                  <span className="text-sm text-gray-300">{title}</span>
                </label>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {activeCards.includes('stats') && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <DashboardCard title="Daily Production" onRemove={() => toggleCard('stats')}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">170</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <ArrowUp className="w-4 h-4 mr-1" />
                  5% vs yesterday
                </p>
              </div>
              <Box className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Work in Progress">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">45</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  In process
                </p>
              </div>
              <Clock className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Quality Rate">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">98.5%</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Pass rate
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Bottlenecks">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">2</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <AlertTriangle className="w-4 h-4 mr-1" />
                  Active alerts
                </p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeCards.includes('productionOverview') && (
          <DashboardCard
            title="Production Overview"
            onRemove={() => toggleCard('productionOverview')}
          >
            <div style={{ height: '300px' }}>
              <Line
                ref={chartRef}
                data={productionData}
                options={chartOptions}
              />
            </div>
          </DashboardCard>
        )}

        {activeCards.includes('orderStatus') && (
          <DashboardCard
            title="Order Status"
            onRemove={() => toggleCard('orderStatus')}
          >
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">In Queue</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-1/4 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">25</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">In Production</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-1/2 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">45</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Quality Check</span>
                <div className="flex items-center">
                  <div className="w-32 h-2 bg-gray-700 rounded-full mr-3">
                    <div className="w-1/6 h-full bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-white">15</span>
                </div>
              </div>
            </div>
          </DashboardCard>
        )}
      </div>

      {activeCards.includes('qualityMetrics') && (
        <DashboardCard
          title="Quality Metrics"
          onRemove={() => toggleCard('qualityMetrics')}
        >
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-400">Pass Rate</p>
              <p className="text-2xl font-semibold text-white">98.5%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Defect Rate</p>
              <p className="text-2xl font-semibold text-white">1.5%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Rework Rate</p>
              <p className="text-2xl font-semibold text-white">0.8%</p>
            </div>
          </div>
        </DashboardCard>
      )}
    </div>
  )
}

export default ProductionDashboard
