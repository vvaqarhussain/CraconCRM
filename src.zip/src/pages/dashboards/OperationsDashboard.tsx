import DashboardCard from '../../components/DashboardCard'

const OperationsDashboard = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Operations Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard title="Project Status">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Active Projects</p>
              <p className="text-2xl font-semibold text-white">24</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">On Track</p>
              <p className="text-2xl font-semibold text-white">92%</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Resource Allocation">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Team Utilization</p>
              <p className="text-2xl font-semibold text-white">87%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Available Resources</p>
              <p className="text-2xl font-semibold text-white">15</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Task Management">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Open Tasks</p>
              <p className="text-2xl font-semibold text-white">156</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Completed Today</p>
              <p className="text-2xl font-semibold text-white">42</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  )
}

export default OperationsDashboard
