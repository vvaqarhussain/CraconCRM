import DashboardCard from '../../components/DashboardCard'

const HRFinanceDashboard = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">HR & Finance Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard title="HR Metrics">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Total Employees</p>
              <p className="text-2xl font-semibold text-white">248</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Open Positions</p>
              <p className="text-2xl font-semibold text-white">12</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Financial Overview">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Revenue (MTD)</p>
              <p className="text-2xl font-semibold text-white">$342,800</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Expenses (MTD)</p>
              <p className="text-2xl font-semibold text-white">$256,400</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Payroll">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Next Payroll</p>
              <p className="text-2xl font-semibold text-white">Apr 30</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Amount</p>
              <p className="text-2xl font-semibold text-white">$186,250</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  )
}

export default HRFinanceDashboard
