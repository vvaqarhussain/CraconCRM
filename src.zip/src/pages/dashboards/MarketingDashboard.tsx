import DashboardCard from '../../components/DashboardCard'

const MarketingDashboard = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Marketing Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <DashboardCard title="Campaign Performance">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Active Campaigns</p>
              <p className="text-2xl font-semibold text-white">12</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Budget</p>
              <p className="text-2xl font-semibold text-white">$24,500</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Social Media">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Total Followers</p>
              <p className="text-2xl font-semibold text-white">45.2K</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Engagement Rate</p>
              <p className="text-2xl font-semibold text-white">3.8%</p>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard title="Content Performance">
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-400">Blog Posts</p>
              <p className="text-2xl font-semibold text-white">128</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Avg. Time on Page</p>
              <p className="text-2xl font-semibold text-white">2:45</p>
            </div>
          </div>
        </DashboardCard>
      </div>
    </div>
  )
}

export default MarketingDashboard
