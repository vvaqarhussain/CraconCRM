import { useEffect, useState, useRef } from 'react'
import { Plus, ArrowUp, Users, CheckCircle, DollarSign } from 'lucide-react'
import { Line } from 'react-chartjs-2'
import type { ChartData, ChartOptions } from 'chart.js'
import { DashboardStats, Lead } from '../../types'
import { getLeads } from '../../utils/storage'
import DashboardCard from '../../components/DashboardCard'
import '../../utils/chartSetup' // Import chart setup

const AVAILABLE_CARDS = {
  leads: 'Leads Generated',
  welcomeEmails: 'Welcome Emails',
  openRate: 'Open Rate',
  conversion: 'Conversion Rate',
  performance: 'Page Performance',
  leadsSource: 'Leads by Source',
  newLeads: 'Newest Leads',
  stats: 'Stats Overview'
} as const

type CardId = keyof typeof AVAILABLE_CARDS

const SalesDashboard = () => {
  const chartRef = useRef<any>(null)
  const [stats, setStats] = useState<DashboardStats>({
    totalLeads: 0,
    newLeads: 0,
    qualifiedLeads: 0,
    closedLeads: 0,
    totalValue: 0,
    avgDealSize: 0,
    conversionRate: 0
  })
  const [recentLeads, setRecentLeads] = useState<Lead[]>([])
  const [leadsByStatus, setLeadsByStatus] = useState<number[]>([])
  const [activeCards, setActiveCards] = useState<CardId[]>(() => {
    const saved = localStorage.getItem('dashboard_cards')
    return saved ? JSON.parse(saved) : Object.keys(AVAILABLE_CARDS)
  })
  const [showCardSelector, setShowCardSelector] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      const leads = getLeads()
      const totalValue = leads.reduce((sum, lead) => sum + (lead.amount || 0), 0)
      
      setStats({
        totalLeads: leads.length,
        newLeads: leads.filter(l => l.status === 'new').length,
        qualifiedLeads: leads.filter(l => l.status === 'qualified').length,
        closedLeads: leads.filter(l => l.status === 'closed').length,
        totalValue,
        avgDealSize: leads.length ? totalValue / leads.length : 0,
        conversionRate: leads.length ? (leads.filter(l => l.status === 'closed').length / leads.length) * 100 : 0
      })
      
      const sortedLeads = [...leads].sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      setRecentLeads(sortedLeads.slice(0, 5))

      setLeadsByStatus([
        leads.filter(l => l.status === 'new').length,
        leads.filter(l => l.status === 'contacted').length,
        leads.filter(l => l.status === 'qualified').length,
        leads.filter(l => l.status === 'proposal').length,
        leads.filter(l => l.status === 'negotiation').length,
        leads.filter(l => l.status === 'closed').length,
      ])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data')
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('dashboard_cards', JSON.stringify(activeCards))
  }, [activeCards])

  // Cleanup function to destroy chart instance
  useEffect(() => {
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy()
      }
    }
  }, [])

  const toggleCard = (cardId: CardId) => {
    if (activeCards.includes(cardId)) {
      setActiveCards(activeCards.filter(id => id !== cardId))
    } else {
      setActiveCards([...activeCards, cardId])
    }
  }

  const chartData: ChartData<'line'> = {
    labels: ['New', 'Contacted', 'Qualified', 'Proposal', 'Negotiation', 'Closed'],
    datasets: [
      {
        label: 'Leads by Status',
        data: leadsByStatus,
        fill: true,
        borderColor: '#f97316',
        backgroundColor: 'rgba(249, 115, 22, 0.1)',
        tension: 0.4,
      },
    ],
  }

  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#1a1a1a',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: '#27272a',
        borderWidth: 1,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
      x: {
        grid: {
          color: '#27272a',
        },
        ticks: {
          color: '#94a3b8',
        },
      },
    },
  }

  if (error) {
    return (
      <div className="text-red-500 p-4">
        Error: {error}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Sales Dashboard</h1>
        <div className="relative">
          <button
            onClick={() => setShowCardSelector(!showCardSelector)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
          >
            <Plus className="w-4 h-4" />
            Manage Cards
          </button>

          {showCardSelector && (
            <div className="absolute right-0 mt-2 w-64 bg-[#1a1a1a] border border-zinc-800 rounded-lg shadow-lg z-10">
              {(Object.entries(AVAILABLE_CARDS) as [CardId, string][]).map(([id, title]) => (
                <label key={id} className="flex items-center px-4 py-2 hover:bg-zinc-800">
                  <input
                    type="checkbox"
                    checked={activeCards.includes(id)}
                    onChange={() => toggleCard(id)}
                    className="mr-3"
                  />
                  <span className="text-sm text-gray-300">{title}</span>
                </label>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {activeCards.includes('stats') && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <DashboardCard title="Total Leads" onRemove={() => toggleCard('stats')}>
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">{stats.totalLeads}</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <ArrowUp className="w-4 h-4 mr-1" />
                  12% vs last month
                </p>
              </div>
              <Users className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="New Leads">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">{stats.newLeads}</p>
              </div>
              <Users className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Qualified Leads">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">{stats.qualifiedLeads}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>

          <DashboardCard title="Closed Deals">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-2xl font-semibold mt-1 text-white">{stats.closedLeads}</p>
                <p className="text-orange-400 text-sm mt-1 flex items-center">
                  <ArrowUp className="w-4 h-4 mr-1" />
                  8% vs last month
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-400" />
            </div>
          </DashboardCard>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeCards.includes('leads') && (
          <DashboardCard
            title="Lead Distribution"
            onRemove={() => toggleCard('leads')}
          >
            <div style={{ height: '300px' }}>
              <Line
                ref={chartRef}
                data={chartData}
                options={chartOptions}
              />
            </div>
          </DashboardCard>
        )}

        {activeCards.includes('welcomeEmails') && (
          <DashboardCard
            title="Welcome Emails Performance"
            onRemove={() => toggleCard('welcomeEmails')}
          >
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-400">Successful delivered</p>
                <p className="text-2xl font-semibold text-white">94.3%</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Click rate</p>
                <p className="text-2xl font-semibold text-white">3.3%</p>
              </div>
            </div>
          </DashboardCard>
        )}
      </div>

      {activeCards.includes('conversion') && (
        <DashboardCard
          title="Conversion Metrics"
          onRemove={() => toggleCard('conversion')}
        >
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-gray-400">Conversion rate</p>
              <p className="text-2xl font-semibold text-white">5.6%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Abandoned form</p>
              <p className="text-2xl font-semibold text-white">40.5%</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Page performance</p>
              <p className="text-2xl font-semibold text-white">6.2s</p>
            </div>
          </div>
        </DashboardCard>
      )}

      {activeCards.includes('leadsSource') && (
        <DashboardCard
          title="Leads by Source"
          onRemove={() => toggleCard('leadsSource')}
        >
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Organic</span>
              <span className="text-white">244</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Paid search</span>
              <span className="text-white">175</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Referral</span>
              <span className="text-white">117</span>
            </div>
          </div>
        </DashboardCard>
      )}
    </div>
  )
}

export default SalesDashboard
