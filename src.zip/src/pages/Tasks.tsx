import { useState, useEffect } from 'react'
import { Calendar, Clock, Flag } from 'lucide-react'
import { Activity, Lead } from '../types'
import { getLeads, saveLead } from '../utils/storage'

const Tasks = () => {
  const [tasks, setTasks] = useState<(Activity & { leadName: string, leadId: string })[]>([])
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending')

  useEffect(() => {
    const leads = getLeads()
    const allTasks = leads.flatMap(lead => 
      (lead.activities || [])
        .filter(activity => activity.type === 'task')
        .map(task => ({
          ...task,
          leadName: lead.name,
          leadId: lead.id
        }))
    )

    setTasks(allTasks)
  }, [])

  const handleCompleteTask = (taskId: string, leadId: string) => {
    const leads = getLeads()
    const lead = leads.find(l => l.id === leadId)
    
    if (lead) {
      const updatedActivities = (lead.activities || []).map(activity =>
        activity.id === taskId
          ? { ...activity, completed: true }
          : activity
      )
      
      const updatedLead: Lead = {
        ...lead,
        activities: updatedActivities
      }
      
      saveLead(updatedLead)
      
      setTasks(prev => prev.map(task =>
        task.id === taskId
          ? { ...task, completed: true }
          : task
      ))
    }
  }

  const filteredTasks = tasks.filter(task => {
    switch (filter) {
      case 'completed':
        return task.completed
      case 'pending':
        return !task.completed
      default:
        return true
    }
  })

  const getPriorityColor = (priority?: 'low' | 'medium' | 'high') => {
    switch (priority) {
      case 'high':
        return 'text-red-400'
      case 'medium':
        return 'text-yellow-400'
      default:
        return 'text-blue-400'
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Tasks</h1>
        
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              filter === 'all'
                ? 'bg-orange-500 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              filter === 'pending'
                ? 'bg-orange-500 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-lg text-sm ${
              filter === 'completed'
                ? 'bg-orange-500 text-white'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredTasks.map(task => (
          <div
            key={task.id}
            className="bg-[#111111] rounded-lg border border-zinc-800 p-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => handleCompleteTask(task.id, task.leadId)}
                    className="rounded border-zinc-600 text-orange-500 focus:ring-orange-500"
                  />
                  <div>
                    <p className={`text-gray-200 ${task.completed ? 'line-through text-gray-500' : ''}`}>
                      {task.content}
                    </p>
                    <p className="text-sm text-gray-400">
                      For lead: {task.leadName}
                    </p>
                  </div>
                </div>
                
                <div className="mt-3 flex gap-4 text-sm">
                  {task.dueDate && (
                    <div className="flex items-center gap-1 text-gray-400">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(task.dueDate).toLocaleDateString()}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-1 text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span>{new Date(task.createdAt).toLocaleDateString()}</span>
                  </div>
                  {task.priority && (
                    <div className={`flex items-center gap-1 ${getPriorityColor(task.priority)}`}>
                      <Flag className="w-4 h-4" />
                      <span className="capitalize">{task.priority}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}

        {filteredTasks.length === 0 && (
          <div className="text-center py-8">
            <p className="text-gray-400">No tasks found</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default Tasks
