import { useState, useEffect } from 'react'
import { Lead } from '../types'
import { getLeads } from '../utils/storage'

const STAGES = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'closed']

const getStageStyles = (stage: string) => {
  switch (stage) {
    case 'new':
      return 'border-l-4 border-l-orange-500 bg-orange-500/5'
    case 'contacted':
      return 'border-l-4 border-l-amber-500 bg-amber-500/5'
    case 'qualified':
      return 'border-l-4 border-l-yellow-500 bg-yellow-500/5'
    case 'proposal':
      return 'border-l-4 border-l-orange-500 bg-orange-500/5'
    case 'negotiation':
      return 'border-l-4 border-l-amber-500 bg-amber-500/5'
    case 'closed':
      return 'border-l-4 border-l-orange-500 bg-orange-500/5'
    default:
      return 'border-l-4 border-l-gray-500 bg-gray-500/5'
  }
}

const Pipeline = () => {
  const [leads, setLeads] = useState<Lead[]>([])

  useEffect(() => {
    setLeads(getLeads())
  }, [])

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6 text-white">Pipeline</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {STAGES.map(stage => {
          const stageLeads = leads.filter(lead => lead.status === stage)
          return (
            <div key={stage} className={`rounded-lg p-4 bg-gradient-to-br from-[#111111] to-[#1a1a1a] border border-zinc-800 ${getStageStyles(stage)}`}>
              <h3 className="text-sm font-medium text-gray-200 mb-3 capitalize flex items-center justify-between">
                <span>{stage}</span>
                <span className="bg-zinc-800 px-2 py-0.5 rounded text-xs">
                  {stageLeads.length}
                </span>
              </h3>
              
              <div className="space-y-2">
                {stageLeads.map(lead => (
                  <div
                    key={lead.id}
                    className="bg-zinc-800/50 p-3 rounded-lg hover:border-orange-500/20 border border-transparent transition-colors"
                  >
                    <p className="font-medium text-sm text-gray-200">{lead.name}</p>
                    <p className="text-gray-400 text-sm">{lead.company}</p>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default Pipeline
