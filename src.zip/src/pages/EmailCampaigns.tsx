import { useState, useEffect } from 'react'
import { Plus, Mail, Clock, Send, Trash2, Edit2 } from 'lucide-react'
import { EmailCampaign } from '../types'
import { getCampaigns, saveCampaign, deleteCampaign } from '../utils/storage'

const EmailCampaigns = () => {
  const [campaigns, setCampaigns] = useState<EmailCampaign[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingCampaign, setEditingCampaign] = useState<EmailCampaign | null>(null)

  useEffect(() => {
    setCampaigns(getCampaigns())
  }, [])

  const handleSave = (campaign: EmailCampaign) => {
    saveCampaign(campaign)
    setCampaigns(getCampaigns())
    setIsModalOpen(false)
    setEditingCampaign(null)
  }

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this campaign?')) {
      deleteCampaign(id)
      setCampaigns(getCampaigns())
    }
  }

  const handleSchedule = (campaign: EmailCampaign) => {
    const scheduled: EmailCampaign = {
      ...campaign,
      status: 'scheduled',
      scheduledFor: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // Schedule for tomorrow
    }
    handleSave(scheduled)
  }

  const handleSend = (campaign: EmailCampaign) => {
    const sent: EmailCampaign = {
      ...campaign,
      status: 'sent',
      sentAt: new Date().toISOString()
    }
    handleSave(sent)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Email Campaigns</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-orange-600 text-white px-4 py-2 rounded-lg flex items-center hover:bg-orange-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Campaign
        </button>
      </div>

      <div className="grid gap-6">
        {campaigns.map(campaign => (
          <div
            key={campaign.id}
            className="bg-[#111111] rounded-lg border border-zinc-800 p-6"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold text-white mb-1">
                  {campaign.name}
                </h3>
                <p className="text-gray-400">{campaign.subject}</p>
              </div>
              
              <div className="flex items-center gap-2">
                {campaign.status === 'draft' && (
                  <>
                    <button
                      onClick={() => handleSchedule(campaign)}
                      className="p-2 text-gray-400 hover:text-gray-300"
                      title="Schedule"
                    >
                      <Clock className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleSend(campaign)}
                      className="p-2 text-gray-400 hover:text-gray-300"
                      title="Send now"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => {
                        setEditingCampaign(campaign)
                        setIsModalOpen(true)
                      }}
                      className="p-2 text-gray-400 hover:text-gray-300"
                      title="Edit"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                  </>
                )}
                <button
                  onClick={() => handleDelete(campaign.id)}
                  className="p-2 text-red-400 hover:text-red-300"
                  title="Delete"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-400">Status</p>
                <p className="text-white capitalize">{campaign.status}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Recipients</p>
                <p className="text-white">{campaign.recipients}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Opened</p>
                <p className="text-white">{campaign.opened}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Clicked</p>
                <p className="text-white">{campaign.clicked}</p>
              </div>
            </div>

            {campaign.status === 'scheduled' && campaign.scheduledFor && (
              <div className="mt-4 flex items-center text-sm text-gray-400">
                <Clock className="w-4 h-4 mr-2" />
                Scheduled for: {new Date(campaign.scheduledFor).toLocaleString()}
              </div>
            )}

            {campaign.status === 'sent' && campaign.sentAt && (
              <div className="mt-4 flex items-center text-sm text-gray-400">
                <Mail className="w-4 h-4 mr-2" />
                Sent at: {new Date(campaign.sentAt).toLocaleString()}
              </div>
            )}
          </div>
        ))}
      </div>

      {isModalOpen && (
        <CampaignModal
          campaign={editingCampaign}
          onClose={() => {
            setIsModalOpen(false)
            setEditingCampaign(null)
          }}
          onSave={handleSave}
        />
      )}
    </div>
  )
}

interface CampaignModalProps {
  campaign?: EmailCampaign | null;
  onClose: () => void;
  onSave: (campaign: EmailCampaign) => void;
}

const CampaignModal = ({ campaign, onClose, onSave }: CampaignModalProps) => {
  const [formData, setFormData] = useState({
    name: campaign?.name || '',
    subject: campaign?.subject || '',
    content: campaign?.content || '',
    recipients: campaign?.recipients || 0
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newCampaign: EmailCampaign = {
      id: campaign?.id || crypto.randomUUID(),
      ...formData,
      status: 'draft',
      opened: campaign?.opened || 0,
      clicked: campaign?.clicked || 0,
      createdAt: campaign?.createdAt || new Date().toISOString()
    }
    onSave(newCampaign)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-[#111111] rounded-lg w-full max-w-lg border border-zinc-800">
        <form onSubmit={handleSubmit} className="p-6">
          <h2 className="text-xl font-semibold text-white mb-6">
            {campaign ? 'Edit Campaign' : 'New Campaign'}
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Campaign Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Subject Line
              </label>
              <input
                type="text"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Email Content
              </label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                rows={6}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Number of Recipients
              </label>
              <input
                type="number"
                value={formData.recipients}
                onChange={(e) => setFormData({ ...formData, recipients: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                min="0"
                required
              />
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-300 hover:bg-zinc-800 border border-zinc-700 rounded-md"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 rounded-md"
            >
              Save Campaign
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default EmailCampaigns
