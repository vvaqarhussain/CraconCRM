export interface Lead {
  id: string;
  month: string;
  dateTime: string;
  name: string;
  company: string;
  phone: string;
  email: string;
  state: string;
  jobTitle: string;
  source: string;
  investment: number;
  service: string;
  status: 'new' | 'contacted' | 'qualified' | 'proposal' | 'negotiation' | 'closed';
  notes: string;
  amount?: number;
  createdAt: string;
  agents: AgentInteraction[];
  activities?: Activity[];
  // New fields
  website?: string;
  industry?: string;
  employeeCount?: number;
  annualRevenue?: number;
  decisionMaker?: string;
  decisionMakerRole?: string;
  priority?: 'low' | 'medium' | 'high';
  lastContactDate?: string;
  nextFollowUp?: string;
  linkedInProfile?: string;
  competitors?: string[];
  tags?: string[];
  customFields?: Record<string, string | number | boolean>;
}

export interface AgentInteraction {
  agentName: string;
  stage: string;
  comments: string;
  date?: string;
  outcome?: string;
  nextSteps?: string;
}

export interface Activity {
  id: string;
  type: 'note' | 'email' | 'call' | 'meeting' | 'task';
  content: string;
  createdAt: string;
  dueDate?: string;
  completed?: boolean;
  priority?: 'low' | 'medium' | 'high';
  assignedTo?: string;
  relatedTo?: string;
}

export interface DashboardStats {
  totalLeads: number;
  newLeads: number;
  qualifiedLeads: number;
  closedLeads: number;
  totalValue: number;
  avgDealSize: number;
  conversionRate: number;
}

export interface EmailCampaign {
  id: string;
  name: string;
  subject: string;
  content: string;
  status: 'draft' | 'scheduled' | 'sent';
  sentAt?: string;
  scheduledFor?: string;
  recipients: number;
  opened: number;
  clicked: number;
  createdAt: string;
}

export interface CustomField {
  id: string;
  name: string;
  type: 'text' | 'number' | 'date' | 'select';
  options?: string[];
  required?: boolean;
}
