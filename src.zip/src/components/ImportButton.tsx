import { useState } from 'react'
import { FileSpreadsheet } from 'lucide-react'
import { importLeadsFromSheet } from '../utils/googleSheets'
import { saveLead } from '../utils/storage'

const ImportButton = ({ onImportComplete }: { onImportComplete: () => void }) => {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleImport = async () => {
    setIsLoading(true)
    setError(null)
    
    try {
      const leads = await importLeadsFromSheet()
      leads.forEach(lead => saveLead(lead))
      onImportComplete()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to import leads')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="relative">
      <button
        onClick={handleImport}
        disabled={isLoading}
        className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <FileSpreadsheet className="w-4 h-4" />
        {isLoading ? 'Importing...' : 'Import from Sheets'}
      </button>
      
      {error && (
        <div className="absolute top-full mt-2 w-64 p-2 text-sm text-red-400 bg-red-900/10 border border-red-900/20 rounded">
          {error}
        </div>
      )}
    </div>
  )
}

export default ImportButton
