import { useState } from 'react';
import CraftConnectLogo from '../assets/CraftConnect FF SVG1-01.svg';
import CraconIcon from '../assets/CraconIcon.svg';

const Logo = ({ className = "" }: { className?: string }) => {
  const [showAlternateLogo, setShowAlternateLogo] = useState(false);

  const handleToggle = () => {
    setShowAlternateLogo(!showAlternateLogo);
  };

  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src={showAlternateLogo ? CraconIcon : CraftConnectLogo} 
        alt="Logo"
        className="logo"
      />
      <label className="switch">
        <input 
          type="checkbox"
          checked={showAlternateLogo}
          onChange={handleToggle}
        />
        <span className="slider"></span>
      </label>
    </div>
  );
};

export default Logo;
