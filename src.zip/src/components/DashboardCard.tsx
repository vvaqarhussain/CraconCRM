import { useState } from 'react'
import { Settings } from 'lucide-react'

interface DashboardCardProps {
  title: string
  children: React.ReactNode
  onRemove?: () => void
}

const DashboardCard = ({ title, children, onRemove }: DashboardCardProps) => {
  const [showSettings, setShowSettings] = useState(false)

  return (
    <div className="bg-gradient-to-br from-[#111111] to-[#1a1a1a] p-6 rounded-xl border border-zinc-800 hover:border-orange-500/20 transition-colors relative">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        {onRemove && (
          <div className="relative">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="text-gray-400 hover:text-gray-300"
            >
              <Settings className="w-5 h-5" />
            </button>
            
            {showSettings && (
              <div className="absolute right-0 mt-2 w-48 bg-[#1a1a1a] border border-zinc-800 rounded-lg shadow-lg z-10">
                <button
                  onClick={onRemove}
                  className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-zinc-800"
                >
                  Remove Card
                </button>
              </div>
            )}
          </div>
        )}
      </div>
      {children}
    </div>
  )
}

export default DashboardCard
