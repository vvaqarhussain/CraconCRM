import { Link, useLocation } from 'react-router-dom'
import { LayoutDashboard, Users, PieChart, TrendingUp, Target, UserCircle, BarChart, CheckSquare, Mail, ChevronLeft, Menu } from 'lucide-react'
import { useState, useEffect } from 'react'
import logoSvg from '../assets/CraconLogo.svg';

const Sidebar = () => {
  const location = useLocation()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  
  // Handle responsive behavior
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsCollapsed(true)
      }
    }
    
    window.addEventListener('resize', handleResize)
    handleResize() // Initial check
    
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  const navigation = [
    { 
      name: 'Dashboards',
      children: [
        { name: 'Leads', icon: Users, path: '/dashboards/leads' },
        { name: 'Sales', icon: TrendingUp, path: '/dashboards/sales' },
        { name: 'Marketing', icon: Target, path: '/dashboards/marketing' },
        { name: 'Lead Generation', icon: Users, path: '/leads' },
        { name: 'eCom Operations', icon: LayoutDashboard, path: '/dashboards/operations' },
        { name: 'Production', icon: PieChart, path: '/dashboards/production' },
        { name: 'Executive', icon: BarChart, path: '/dashboards/executive' },
      ]
    },
    { name: 'Pipeline', icon: PieChart, path: '/pipeline' },
    { name: 'Tasks', icon: CheckSquare, path: '/tasks' },
    { name: 'Email Campaigns', icon: Mail, path: '/campaigns' },
  ]

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-orange-600 text-white"
      >
        <Menu className="w-6 h-6" />
      </button>

      <div
        className={`fixed inset-0 bg-black/50 z-40 transition-opacity md:hidden ${
          isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsMobileMenuOpen(false)}
      />

      <div 
        className={`h-screen bg-white dark:bg-[#24283b] p-4 fixed left-0 top-0 border-r border-zinc-200 dark:border-zinc-800 z-40 transition-all duration-300 ${
          isCollapsed ? 'w-20' : 'w-64'
        } ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}
      >
        <div className="flex items-center justify-between mb-4 w-full">
          <img src={logoSvg} alt="Cracon Logo" className="w-[85%] h-auto" />
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-[#363b54] transition-colors hidden md:block"
          >
            <ChevronLeft className={`w-5 h-5 transition-transform ${isCollapsed ? 'rotate-180' : ''}`} />
          </button>
        </div>
        
        <nav className="space-y-1">
          {navigation.map((item) => {
            if (item.children) {
              return (
                <div key={item.name} className="mb-4">
                  {!isCollapsed && (
                    <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                      {item.name}
                    </h3>
                  )}
                  <div className="space-y-1">
                    {item.children.map((child) => {
                      const isActive = location.pathname === child.path
                      return (
                        <Link
                          key={child.name}
                          to={child.path}
                          className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium ${
                            isActive
                              ? 'bg-orange-500/10 text-orange-500 dark:text-orange-400'
                              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#363b54]'
                          }`}
                          title={isCollapsed ? child.name : undefined}
                        >
                          <child.icon className={`${isCollapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
                          {!isCollapsed && child.name}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              )
            }

            const isActive = location.pathname === item.path
            return (
              <Link
                key={item.name}
                to={item.path}
                className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium ${
                  isActive
                    ? 'bg-orange-500/10 text-orange-500 dark:text-orange-400'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-[#363b54]'
                }`}
                title={isCollapsed ? item.name : undefined}
              >
                <item.icon className={`${isCollapsed ? 'mx-auto' : 'mr-3'} h-5 w-5`} />
                {!isCollapsed && item.name}
              </Link>
            )
          })}
        </nav>
      </div>
    </>
  )
}

export default Sidebar
