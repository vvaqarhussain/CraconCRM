import { useState } from 'react'
import { HelpCircle } from 'lucide-react'

const PanelGuide = () => {
  const [isOpen, setIsOpen] = useState(false)

  const panels = [
    {
      name: 'Navigation Sidebar',
      description: 'Left panel containing the main navigation menu and theme toggle'
    },
    {
      name: 'Main Content Area',
      description: 'Primary panel that displays the current view (Dashboard, Leads, or Pipeline)'
    },
    {
      name: 'Dashboard Stats Cards',
      description: 'Small panels on the Dashboard showing key metrics and statistics'
    },
    {
      name: 'Pipeline Stages',
      description: 'Vertical column panels showing leads organized by their current stage'
    },
    {
      name: 'Leads Table',
      description: 'Data table panel displaying lead information in rows and columns'
    },
    {
      name: 'Lead Modal',
      description: 'Popup panel for adding or editing lead details'
    }
  ]

  return (
    <div className="fixed bottom-4 right-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-full"
        title="Show panel guide"
      >
        <HelpCircle className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="absolute bottom-12 right-0 w-80 bg-[#111111] border border-zinc-800 rounded-lg shadow-lg p-4">
          <h3 className="text-lg font-semibold text-white mb-3">Panel Guide</h3>
          <div className="space-y-3">
            {panels.map((panel) => (
              <div key={panel.name} className="text-sm">
                <h4 className="text-purple-400 font-medium">{panel.name}</h4>
                <p className="text-gray-400">{panel.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default PanelGuide
