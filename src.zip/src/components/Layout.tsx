import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import PanelGuide from './PanelGuide'

const Layout = () => {
  return (
    <div className="min-h-screen">
      <Sidebar />
      <main className="transition-all duration-300 md:ml-20 lg:ml-64 p-4 md:p-8">
        <Outlet />
      </main>
      <PanelGuide />
    </div>
  )
}

export default Layout
