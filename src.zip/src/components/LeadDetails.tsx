import { MessageSquare, Mail, Phone, Calendar, MapPin, Briefcase, DollarSign, User } from 'lucide-react'
import { Lead, Activity } from '../types'

interface LeadDetailsProps {
  lead: Lead;
  onAddActivity: (activity: Omit<Activity, 'id' | 'createdAt'>) => void;
}

const ActivityItem = ({ activity }: { activity: Activity }) => {
  const getIcon = (type: Activity['type']) => {
    switch (type) {
      case 'note':
        return <MessageSquare className="w-4 h-4" />;
      case 'email':
        return <Mail className="w-4 h-4" />;
      case 'call':
        return <Phone className="w-4 h-4" />;
      case 'meeting':
        return <Calendar className="w-4 h-4" />;
    }
  }

  return (
    <div className="flex gap-3">
      <div className="mt-1 text-orange-400">
        {getIcon(activity.type)}
      </div>
      <div>
        <p className="text-sm text-gray-300">{activity.content}</p>
        <p className="text-xs text-gray-500 mt-1">
          {new Date(activity.createdAt).toLocaleString()}
        </p>
      </div>
    </div>
  )
}

const LeadDetails = ({ lead, onAddActivity }: LeadDetailsProps) => {
  const handleAddNote = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const content = new FormData(form).get('content') as string
    
    if (content.trim()) {
      onAddActivity({
        type: 'note',
        content
      })
      form.reset()
    }
  }

  return (
    <div className="bg-[#111111] rounded-lg border border-zinc-800 p-6">
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <p className="text-sm text-gray-400">Investment</p>
          <p className="text-lg font-semibold text-white">
            ${lead.investment?.toLocaleString() || '0'}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-400">Created</p>
          <p className="text-lg text-white">
            {new Date(lead.dateTime).toLocaleDateString()}
          </p>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-white mb-3">Contact Info</h3>
        <div className="space-y-2">
          <p className="text-sm text-gray-300">
            <Mail className="w-4 h-4 inline mr-2 text-gray-400" />
            {lead.email}
          </p>
          <p className="text-sm text-gray-300">
            <Phone className="w-4 h-4 inline mr-2 text-gray-400" />
            {lead.phone}
          </p>
          <p className="text-sm text-gray-300">
            <MapPin className="w-4 h-4 inline mr-2 text-gray-400" />
            {lead.state}
          </p>
          <p className="text-sm text-gray-300">
            <Briefcase className="w-4 h-4 inline mr-2 text-gray-400" />
            {lead.jobTitle}
          </p>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-white mb-3">Service Details</h3>
        <div className="space-y-2">
          <p className="text-sm text-gray-300">
            <DollarSign className="w-4 h-4 inline mr-2 text-gray-400" />
            Service: {lead.service}
          </p>
          <p className="text-sm text-gray-300">
            Source: {lead.source}
          </p>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-white mb-3">Agent Interactions</h3>
        <div className="space-y-4">
          {lead.agents.map((agent, index) => (
            <div key={index} className="bg-zinc-900 p-3 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <User className="w-4 h-4 text-orange-400" />
                <p className="text-sm font-medium text-gray-200">{agent.agentName}</p>
              </div>
              <p className="text-sm text-gray-400 mb-1">Stage: {agent.stage}</p>
              {agent.comments && (
                <p className="text-sm text-gray-300">
                  Comments: {agent.comments}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-white mb-3">Activity</h3>
        <form onSubmit={handleAddNote} className="mb-4">
          <div className="flex gap-2">
            <input
              type="text"
              name="content"
              placeholder="Add a note..."
              className="flex-1 px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700"
            >
              Add
            </button>
          </div>
        </form>

        <div className="space-y-4">
          {lead.activities?.map(activity => (
            <ActivityItem key={activity.id} activity={activity} />
          ))}
        </div>
      </div>
    </div>
  )
}

export default LeadDetails
