import { useState, useEffect } from 'react'
import { X, Trash2 } from 'lucide-react'
import { Lead } from '../types'

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (lead: Lead) => void;
  onDelete?: (id: string) => void;
  lead?: Lead | null;
}

const STAGES = ['new', 'contacted', 'qualified', 'proposal', 'negotiation', 'closed']

const LeadModal = ({ isOpen, onClose, onSave, onDelete, lead }: LeadModalProps) => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    status: 'new',
    notes: '',
    amount: 0
  })

  useEffect(() => {
    if (lead) {
      setFormData({
        name: lead.name,
        company: lead.company,
        email: lead.email,
        phone: lead.phone,
        status: lead.status,
        notes: lead.notes,
        amount: lead.amount || 0
      })
    } else {
      setFormData({
        name: '',
        company: '',
        email: '',
        phone: '',
        status: 'new',
        notes: '',
        amount: 0
      })
    }
  }, [lead])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newLead: Lead = {
      id: lead?.id || crypto.randomUUID(),
      ...formData,
      createdAt: lead?.createdAt || new Date().toISOString(),
      activities: lead?.activities || []
    }
    onSave(newLead)
  }

  const handleDelete = () => {
    if (lead && onDelete && window.confirm('Are you sure you want to delete this lead?')) {
      onDelete(lead.id)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-[#111111] rounded-lg w-full max-w-md border border-zinc-800">
        <div className="flex justify-between items-center p-4 border-b border-zinc-800">
          <h2 className="text-lg font-semibold text-white">
            {lead ? 'Edit Lead' : 'Add Lead'}
          </h2>
          <div className="flex gap-2">
            {lead && onDelete && (
              <button 
                onClick={handleDelete}
                className="text-red-500 hover:text-red-400"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
            <button onClick={onClose}>
              <X className="w-5 h-5 text-gray-400 hover:text-gray-300" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Company
              </label>
              <input
                type="text"
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Phone
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Deal Value
              </label>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as Lead['status'] })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
              >
                {STAGES.map(stage => (
                  <option key={stage} value={stage}>
                    {stage.charAt(0).toUpperCase() + stage.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Notes
              </label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-md text-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-500"
                rows={3}
              />
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-300 hover:bg-zinc-800 border border-zinc-700 rounded-md"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-orange-600 hover:bg-orange-700 rounded-md"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default LeadModal
