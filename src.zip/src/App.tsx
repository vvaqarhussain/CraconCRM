import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import SalesDashboard from './pages/dashboards/SalesDashboard'
import MarketingDashboard from './pages/dashboards/MarketingDashboard'
import OperationsDashboard from './pages/dashboards/OperationsDashboard'
import HRFinanceDashboard from './pages/dashboards/HRFinanceDashboard'
import ExecutiveDashboard from './pages/dashboards/ExecutiveDashboard'
import LeadsDashboard from './pages/dashboards/LeadsDashboard'
import ProductionDashboard from './pages/dashboards/ProductionDashboard'
import Leads from './pages/Leads'
import Pipeline from './pages/Pipeline'
import Tasks from './pages/Tasks'
import EmailCampaigns from './pages/EmailCampaigns'
import { ThemeProvider } from './context/ThemeContext'
import './index.css'

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-[#1a1b26] text-gray-900 dark:text-gray-100">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Navigate to="/dashboards/leads" replace />} />
              <Route path="dashboards/leads" element={<LeadsDashboard />} />
              <Route path="dashboards/sales" element={<SalesDashboard />} />
              <Route path="dashboards/marketing" element={<MarketingDashboard />} />
              <Route path="dashboards/operations" element={<OperationsDashboard />} />
              <Route path="dashboards/hr-finance" element={<HRFinanceDashboard />} />
              <Route path="dashboards/production" element={<ProductionDashboard />} />
              <Route path="dashboards/executive" element={<ExecutiveDashboard />} />
              <Route path="leads" element={<Leads />} />
              <Route path="pipeline" element={<Pipeline />} />
              <Route path="tasks" element={<Tasks />} />
              <Route path="campaigns" element={<EmailCampaigns />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </div>
    </ThemeProvider>
  )
}

export default App
